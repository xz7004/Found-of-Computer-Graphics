from rit_window import RitWindow
from cgI_engine import CGIengine
from vertex import Vertex
import numpy as np

# Test-specific action function
def default_action():
    # Clear the framebuffer
    myEngine.clearFB(0.25, 0.25, 0.75)
    myEngine.defineViewWindow(800, 0, 800, 0)

    triangle_vertices = [
        -1.0, -1.0, -5.0,  # Vertex 1
        1.0, -1.0, -5.0,  # Vertex 2
        0.0, 1.0, -5.0  # Vertex 3
    ]

    # Set up the camera
    eye = [0.0, 0.0, 0.0]
    lookat = [0.0, 0.0, -10.0]
    up = [0.0, 1.0, 0.0]
    viewT = myEngine.lookAt(eye, lookat, up)
    projectionT = myEngine.ortho3D(-3.0, 3.0, -3.0, 3.0, 0.1, 30.0)

    # Model transformation (identity for simplicity)
    modelT = myEngine.identity3D()

    triangle_indices = [0, 1, 2]  # One triangle
    triangle_normals = [0.0, 0.0, 1.0,  # Normal for Vertex 1
                        0.0, 0.0, 1.0,  # Normal for Vertex 2
                        0.0, 0.0, 1.0]  # Normal for Vertex 3

    myEngine.drawTrianglesPhong(triangle_vertices, triangle_indices, triangle_normals,
                                modelT, viewT, projectionT, [1.0, 0.0, 0.0], [1.0, 1.0, 1.0],
                                [0.2, 0.4, 0.4], 10.0, [-2.0, 3.0, -2.0], [1.0, 1.0, 1.0],
                                [1.0, 1.0, 1.0], False)
# Create the window and engine
window = RitWindow(800, 800)
myEngine = CGIengine(window, default_action)

# Main entry point
if __name__ == "__main__":
    window.run(myEngine)
