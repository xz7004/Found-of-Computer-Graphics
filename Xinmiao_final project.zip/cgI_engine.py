from rit_window import *
from vertex import *
import numpy as np
import glm

class CGIengine:
    def __init__(self, myWindow, defaction):
        self.w_width = myWindow.width
        self.w_height = myWindow.height
        self.win = myWindow
        self.default_action = defaction
        self.matrix_stack = [np.identity(4)]
        self.drawn_pixels = set()
        # Z-buffer
        self.z_buffer = np.full((self.w_width, self.w_height), np.inf)  # Initialize z-buffer to infinity


    def go(self):
        self.drawn_pixels.clear()
        self.z_buffer.fill(np.inf)
        self.default_action()
        self.win.applyFB()

    def clearFB(self, r, g, b):
        self.win.clearFB(r, g, b)

    def pushMatrix(self, matrix):
        if len(self.matrix_stack) > 0:
            top_matrix = self.matrix_stack[-1]
            # Multiply the top of the stack with the new matrix and push the result
            self.matrix_stack.append(np.dot(top_matrix, matrix))
        else:
            # If stack is empty, push the matrix as the first item
            self.matrix_stack.append(matrix)

    def popMatrix(self):
        if len(self.matrix_stack) > 1:
            self.matrix_stack.pop()
        else:
            print("Error: Matrix stack is empty or only contains the identity matrix!")

    def getCurrentMatrix(self):
        if len(self.matrix_stack) > 0:
            return self.matrix_stack[-1]
        else:
            return np.eye(4)  # Return identity if stack is empty

    def identity3D(self):
        return np.eye(4)

    def translate3D(self, tx, ty, tz):
        return np.array([
            [1, 0, 0, tx],
            [0, 1, 0, ty],
            [0, 0, 1, tz],
            [0, 0, 0, 1]
        ])

    def scale3D(self, sx, sy, sz):
        return np.array([
            [sx, 0, 0, 0],
            [0, sy, 0, 0],
            [0, 0, sz, 0],
            [0, 0, 0, 1]
        ])

    def rotateX(self, angle_degrees):
        angle = np.radians(angle_degrees)  # degrees to radians
        cos_theta = np.cos(angle)
        sin_theta = np.sin(angle)
        return np.array([
            [1, 0, 0, 0],
            [0, cos_theta, -sin_theta, 0],
            [0, sin_theta, cos_theta, 0],
            [0, 0, 0, 1]
        ])

    def rotateY(self, angle_degrees):
        angle = np.radians(angle_degrees)
        cos_theta = np.cos(angle)
        sin_theta = np.sin(angle)
        return np.array([
            [cos_theta, 0, sin_theta, 0],
            [0, 1, 0, 0],
            [-sin_theta, 0, cos_theta, 0],
            [0, 0, 0, 1]
        ])

    def rotateZ(self, angle_degrees):
        angle = np.radians(angle_degrees)
        cos_theta = np.cos(angle)
        sin_theta = np.sin(angle)
        return np.array([
            [cos_theta, -sin_theta, 0, 0],
            [sin_theta, cos_theta, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

    def ortho3D(self, l, r, b, t, n, f):
        if n == f:
            f += 1e-5

        if l == r:
            r += 1e-5

        if b == t:
            t += 1e-5
        # orthographic projection matrix
        return np.array([
            [2 / (r - l), 0, 0, -(r + l) / (r - l)],
            [0, 2 / (t - b), 0, -(t + b) / (t - b)],
            [0, 0, -2 / (f - n), -(f + n) / (f - n)],
            [0, 0, 0, 1]
        ])

    def frustum3D(self, l, r, b, t, n, f):
        return np.array([
            [(2 * n) / (r - l), 0, (r + l) / (r - l), 0],
            [0, (2 * n) / (t - b), (t + b) / (t - b), 0],
            [0, 0, -(f + n) / (f - n), -(2 * f * n) / (f - n)],
            [0, 0, -1, 0]
        ])

    def lookAt(self, eye, lookat, up):
        eye = np.array(eye)
        lookat = np.array(lookat)
        up = np.array(up)
        n = lookat - eye
        n = n / np.linalg.norm(n)
        u = np.cross(n, up)
        u = u / np.linalg.norm(u)
        v = np.cross(u, n)
        rotation = np.array([
            [u[0], u[1], u[2], 0],
            [v[0], v[1], v[2], 0],
            [-n[0], -n[1], -n[2], 0],
            [0, 0, 0, 1]
        ])
        translation = np.array([
            [1, 0, 0, -eye[0]],
            [0, 1, 0, -eye[1]],
            [0, 0, 1, -eye[2]],
            [0, 0, 0, 1]
        ])
        view_matrix = rotation @ translation
        return view_matrix

    def defineViewWindow(self, t, b, r, l):
        self.view_window = np.array([
            [(r - l) / 2.0, 0, 0, (r + l) / 2.0],
            [0, (t - b) / 2.0, 0, (t + b) / 2.0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

    def transform_vertex(self, vertex, modelT, viewT, projectionT):
        vertex_h = np.append(vertex, 1)
        transformed = projectionT @ viewT @ modelT @ vertex_h
        transformed /= transformed[3]
        return transformed[:3]


    def compute_normal(self, v0, v1, v2):
        edge1 = v1 - v0
        edge2 = v2 - v0
        normal = np.cross(edge1, edge2)
        return normal / np.linalg.norm(normal)

    def drawTriangles3D(self, vertex_data, index_data, modelT, viewT, projectionT, r, g, b, wr=None, wg=None, wb=None):
        #transformations and render each triangle
        for i in range(0, len(index_data), 3):
            idx0, idx1, idx2 = index_data[i], index_data[i + 1], index_data[i + 2]

            # homogeneous coordinates for each vertex
            p0 = np.array([vertex_data[idx0 * 3], vertex_data[idx0 * 3 + 1], vertex_data[idx0 * 3 + 2], 1])
            p1 = np.array([vertex_data[idx1 * 3], vertex_data[idx1 * 3 + 1], vertex_data[idx1 * 3 + 2], 1])
            p2 = np.array([vertex_data[idx2 * 3], vertex_data[idx2 * 3 + 1], vertex_data[idx2 * 3 + 2], 1])

            # model, view, and projection transformations
            p0 = np.dot(projectionT, np.dot(viewT, np.dot(modelT, p0)))
            p1 = np.dot(projectionT, np.dot(viewT, np.dot(modelT, p1)))
            p2 = np.dot(projectionT, np.dot(viewT, np.dot(modelT, p2)))

            # normalize homogeneous coordinates
            p0 /= p0[3]
            p1 /= p1[3]
            p2 /= p2[3]

            # viewport transformation
            p0 = np.dot(self.view_window, p0)
            p1 = np.dot(self.view_window, p1)
            p2 = np.dot(self.view_window, p2)

            # convert to Vertex objects for rasterization (with z included)
            v0 = Vertex(p0[0], p0[1], p0[2], r, g, b)
            v1 = Vertex(p1[0], p1[1], p1[2], r, g, b)
            v2 = Vertex(p2[0], p2[1], p2[2], r, g, b)

            # Rasterize the triangle with optional edge color
            self.rasterizeTriangle3D(v0, v1, v2, r, g, b, wr, wg, wb)
    def rasterizeTriangle3D(self, v0, v1, v2, fill_r, fill_g, fill_b, edge_r=None, edge_g=None, edge_b=None):
        # Determine bounding box for the triangle
        min_x = max(0, int(min(v0.x, v1.x, v2.x)))
        max_x = min(self.w_width - 1, int(max(v0.x, v1.x, v2.x)))
        min_y = max(0, int(min(v0.y, v1.y, v2.y)))
        max_y = min(self.w_height - 1, int(max(v0.y, v1.y, v2.y)))

        # barycentric coordinates
        def edgeFunction(v0, v1, p):
            return (p[0] - v0.x) * (v1.y - v0.y) - (p[1] - v0.y) * (v1.x - v0.x)

        area = edgeFunction(v0, v1, [v2.x, v2.y])

        if abs(area) < 1e-7:
            return

        # rasterize with Z-buffering and edge detection
        for x in range(min_x, max_x + 1):
            for y in range(min_y, max_y + 1):
                p = [x, y]
                w0 = edgeFunction(v1, v2, p)
                w1 = edgeFunction(v2, v0, p)
                w2 = edgeFunction(v0, v1, p)

                # if the point is inside the triangle
                if w0 >= 0 and w1 >= 0 and w2 >= 0:
                    lambda0 = w0 / area
                    lambda1 = w1 / area
                    lambda2 = w2 / area

                    # z-value
                    z = lambda0 * v0.z + lambda1 * v1.z + lambda2 * v2.z

                    if z < self.z_buffer[x, y]:
                        self.z_buffer[x, y] = z

                        edge_threshold = 0.02 * np.sqrt(abs(area))  # based on triangle's size

                        if edge_r is not None and (
                                abs(lambda0) < edge_threshold or
                                abs(lambda1) < edge_threshold or
                                abs(lambda2) < edge_threshold
                        ):

                            self.win.set_pixel(x, y, edge_r, edge_g, edge_b)
                        else:
                            color_r = lambda0 * v0.r + lambda1 * v1.r + lambda2 * v2.r
                            color_g = lambda0 * v0.g + lambda1 * v1.g + lambda2 * v2.g
                            color_b = lambda0 * v0.b + lambda1 * v1.b + lambda2 * v2.b
                            self.win.set_pixel(x, y, color_r, color_g, color_b)

    def drawTrianglesPhong(self, vertex_pos, indices, normals, modelT, viewT, projectionT, ocolor, scolor, k, exponent,
                           lightpos, lightcolor, amb_color, doGouraud):

        lightpos_view = viewT @ np.append(lightpos, 1.0)
        lightpos_view = lightpos_view[:3] / lightpos_view[3]  # Normalize

        transformed_vertices = []
        transformed_normals = []
        gouraud_colors = []

        for i in range(0, len(vertex_pos), 3):
            vertex = np.array([vertex_pos[i], vertex_pos[i + 1], vertex_pos[i + 2]])
            normal = np.array([normals[i], normals[i + 1], normals[i + 2]])

            # vertex to world and view space
            world_pos = modelT @ np.append(vertex, 1.0)
            view_pos = viewT @ world_pos
            view_pos = view_pos[:3] / view_pos[3]

            # vertex to clip space for rasterization
            clip_pos = projectionT @ np.append(view_pos, 1.0)
            clip_pos /= clip_pos[3]

            # Transform to view space
            view_normal = viewT[:3, :3] @ (modelT[:3, :3] @ normal)
            view_normal /= np.linalg.norm(view_normal)  # Normalize

            # Gouraud shading
            if doGouraud:
                view_dir = -view_pos / np.linalg.norm(view_pos)
                color = self.phong_shading(view_pos, view_normal, view_dir, ocolor, scolor, k, exponent, lightpos_view,
                                           lightcolor, amb_color)
                gouraud_colors.append(color)

            # Append transformed data
            transformed_vertices.append((clip_pos[:3], view_pos))
            transformed_normals.append(view_normal)

        # Rasterize each triangle
        for i in range(0, len(indices), 3):
            idx0, idx1, idx2 = indices[i], indices[i + 1], indices[i + 2]
            #print(f"Processing triangle indices: {idx0}, {idx1}, {idx2}")

            # Extract transformed data
            p0, v0_view = transformed_vertices[idx0]
            p1, v1_view = transformed_vertices[idx1]
            p2, v2_view = transformed_vertices[idx2]

            n0 = transformed_normals[idx0]
            n1 = transformed_normals[idx1]
            n2 = transformed_normals[idx2]

            # screen space
            p0 = np.dot(self.view_window, np.append(p0, 1))
            p1 = np.dot(self.view_window, np.append(p1, 1))
            p2 = np.dot(self.view_window, np.append(p2, 1))

            if doGouraud:
                c0, c1, c2 = gouraud_colors[idx0], gouraud_colors[idx1], gouraud_colors[idx2]
                v0 = Vertex(p0[0], p0[1], p0[2], c0[0], c0[1], c0[2])
                v1 = Vertex(p1[0], p1[1], p1[2], c1[0], c1[1], c1[2])
                v2 = Vertex(p2[0], p2[1], p2[2], c2[0], c2[1], c2[2])
            else:
                v0 = Vertex(p0[0], p0[1], p0[2], 0, 0, 0)
                v1 = Vertex(p1[0], p1[1], p1[2], 0, 0, 0)
                v2 = Vertex(p2[0], p2[1], p2[2], 0, 0, 0)

            self.rasterizeTrianglePhong(v0, v1, v2, ocolor, scolor, k, exponent, lightpos_view, lightcolor, amb_color,
                                   doGouraud, n0, n1, n2, v0_view, v1_view, v2_view)

    def rasterizeTrianglePhong(self, v0, v1, v2, ocolor, scolor, k, exponent, lightpos_view, lightcolor, amb_color,
                          doGouraud, n0, n1, n2, v0_view, v1_view, v2_view):

        min_x = max(0, int(min(v0.x, v1.x, v2.x)))
        max_x = min(self.w_width - 1, int(max(v0.x, v1.x, v2.x)))
        min_y = max(0, int(min(v0.y, v1.y, v2.y)))
        max_y = min(self.w_height - 1, int(max(v0.y, v1.y, v2.y)))

        def edgeFunction(v0, v1, p):
            return (p[0] - v0.x) * (v1.y - v0.y) - (p[1] - v0.y) * (v1.x - v0.x)

        area = edgeFunction(v0, v1, [v2.x, v2.y])
        if abs(area) < 1e-7:
            return

        for x in range(min_x, max_x + 1):
            for y in range(min_y, max_y + 1):
                p = [x, y]
                w0 = edgeFunction(v1, v2, p)
                w1 = edgeFunction(v2, v0, p)
                w2 = edgeFunction(v0, v1, p)

                if w0 >= 0 and w1 >= 0 and w2 >= 0:
                    lambda0 = w0 / area
                    lambda1 = w1 / area
                    lambda2 = w2 / area

                    z = lambda0 * v0.z + lambda1 * v1.z + lambda2 * v2.z

                    if z < self.z_buffer[x, y]:
                        self.z_buffer[x, y] = z

                        if doGouraud:

                            color_r = lambda0 * v0.r + lambda1 * v1.r + lambda2 * v2.r
                            color_g = lambda0 * v0.g + lambda1 * v1.g + lambda2 * v2.g
                            color_b = lambda0 * v0.b + lambda1 * v1.b + lambda2 * v2.b
                        else:
                            interp_normal = lambda0 * n0 + lambda1 * n1 + lambda2 * n2
                            interp_normal /= np.linalg.norm(interp_normal)

                            #view space
                            fragment_pos_view = (
                                    lambda0 * v0_view +
                                    lambda1 * v1_view +
                                    lambda2 * v2_view
                            )

                            view_dir = -fragment_pos_view  # View direction
                            view_dir /= np.linalg.norm(view_dir)

                            color = self.phong_shading(
                                fragment_pos_view, interp_normal, view_dir,
                                ocolor, scolor, k, exponent, lightpos_view, lightcolor, amb_color
                            )

                            color_r, color_g, color_b = np.clip(color, 0.0, 1.0)

                        self.win.set_pixel(x, y, color_r, color_g, color_b)

    def phong_shading(self, pos, normal, view_dir, ocolor, scolor, k, exponent, lightpos, lightcolor, amb_color):
        normal = np.array(normal)
        normal /= np.linalg.norm(normal)

        view_dir = np.array(view_dir)
        view_dir /= np.linalg.norm(view_dir)

        light_dir = np.array(lightpos) - np.array(pos)
        light_dir /= np.linalg.norm(light_dir)

        ambient = k[0] * np.array(amb_color) * np.array(ocolor)

        ndotl = max(np.dot(normal, light_dir), 0.0)  # Ensure no negative contribution
        diffuse = k[1] * ndotl * np.array(lightcolor) * np.array(ocolor)

        reflect_dir = 2 * np.dot(light_dir, normal) * normal - light_dir
        reflect_dir /= np.linalg.norm(reflect_dir)
        rdotv = max(np.dot(reflect_dir, view_dir), 0.0)  # Reflect-View dot product
        specular = k[2] * (rdotv ** exponent) * np.array(scolor) * np.array(lightcolor)

        final_color = ambient + diffuse + specular
        return np.clip(final_color, 0.0, 1.0)  # Clamp the result to ensure valid RGB values



    def drawTrianglesTextures(self, vertex_pos, indices, uv, im, modelT, viewT, projectionT):

        texture = np.asarray(im) / 255.0  # Normalize the image to [0, 1]
        tex_h, tex_w, _ = texture.shape

        for i in range(0, len(indices), 3):
            idx0, idx1, idx2 = indices[i], indices[i + 1], indices[i + 2]

            p0 = np.array([vertex_pos[idx0 * 3], vertex_pos[idx0 * 3 + 1], vertex_pos[idx0 * 3 + 2], 1])
            p1 = np.array([vertex_pos[idx1 * 3], vertex_pos[idx1 * 3 + 1], vertex_pos[idx1 * 3 + 2], 1])
            p2 = np.array([vertex_pos[idx2 * 3], vertex_pos[idx2 * 3 + 1], vertex_pos[idx2 * 3 + 2], 1])

            p0 = projectionT @ viewT @ modelT @ p0
            p1 = projectionT @ viewT @ modelT @ p1
            p2 = projectionT @ viewT @ modelT @ p2

            p0 /= p0[3]
            p1 /= p1[3]
            p2 /= p2[3]

            p0[0] = int((p0[0] + 1) * 0.5 * self.w_width)
            p0[1] = int((p0[1] + 1) * 0.5 * self.w_height)  # Fix: Adjust Y-axis mapping
            p1[0] = int((p1[0] + 1) * 0.5 * self.w_width)
            p1[1] = int((p1[1] + 1) * 0.5 * self.w_height)  # Fix: Adjust Y-axis mapping
            p2[0] = int((p2[0] + 1) * 0.5 * self.w_width)
            p2[1] = int((p2[1] + 1) * 0.5 * self.w_height)  # Fix: Adjust Y-axis mapping

            uv0 = [uv[idx0 * 2], uv[idx0 * 2 + 1]]
            uv1 = [uv[idx1 * 2], uv[idx1 * 2 + 1]]
            uv2 = [uv[idx2 * 2], uv[idx2 * 2 + 1]]

            self.rasterizeTriangleTexture(p0, p1, p2, uv0, uv1, uv2, texture, tex_w, tex_h)

    def rasterizeTriangleTexture(self, p0, p1, p2, uv0, uv1, uv2, texture, tex_w, tex_h):
        min_x = max(0, int(min(p0[0], p1[0], p2[0])))
        max_x = min(self.w_width - 1, int(max(p0[0], p1[0], p2[0])))
        min_y = max(0, int(min(p0[1], p1[1], p2[1])))
        max_y = min(self.w_height - 1, int(max(p0[1], p1[1], p2[1])))

        def edgeFunction(v0, v1, p):
            return (p[0] - v0[0]) * (v1[1] - v0[1]) - (p[1] - v0[1]) * (v1[0] - v0[0])

        area = edgeFunction(p0, p1, p2)

        if abs(area) < 1e-7:
            #print("Triangle has zero area; skipping.")
            return

        for x in range(min_x, max_x + 1):
            for y in range(min_y, max_y + 1):
                p = [x, y]
                w0 = edgeFunction(p1, p2, p)
                w1 = edgeFunction(p2, p0, p)
                w2 = edgeFunction(p0, p1, p)

                if w0 >= 0 and w1 >= 0 and w2 >= 0:

                    w0 /= area
                    w1 /= area
                    w2 /= area

                    z = w0 * p0[2] + w1 * p1[2] + w2 * p2[2]

                    if z < self.z_buffer[x, y]:
                        self.z_buffer[x, y] = z

                        u = w0 * uv0[0] + w1 * uv1[0] + w2 * uv2[0]
                        v = w0 * uv0[1] + w1 * uv1[1] + w2 * uv2[1]

                        tex_x = int(u * (tex_w - 1))
                        tex_y = int(v * (tex_h - 1))

                        tex_x = np.clip(tex_x, 0, tex_w - 1)
                        tex_y = np.clip(tex_y, 0, tex_h - 1)

                        color = texture[tex_y, tex_x]
                        #print(f"Pixel ({x}, {y}): Z={z}, Color={color}")

                        self.win.set_pixel(x, y, color[0], color[1], color[2])

    def drawTrianglesCheckerboard(self, vertex_pos, indices, uvs, color1, color2, checksize, modelT, viewT,
                                  projectionT):

        for i in range(0, len(indices), 3):

            idx0, idx1, idx2 = indices[i], indices[i + 1], indices[i + 2]

            p0 = np.array([vertex_pos[idx0 * 3], vertex_pos[idx0 * 3 + 1], vertex_pos[idx0 * 3 + 2], 1])
            p1 = np.array([vertex_pos[idx1 * 3], vertex_pos[idx1 * 3 + 1], vertex_pos[idx1 * 3 + 2], 1])
            p2 = np.array([vertex_pos[idx2 * 3], vertex_pos[idx2 * 3 + 1], vertex_pos[idx2 * 3 + 2], 1])

            p0 = projectionT @ viewT @ modelT @ p0
            p1 = projectionT @ viewT @ modelT @ p1
            p2 = projectionT @ viewT @ modelT @ p2

            p0 /= p0[3]
            p1 /= p1[3]
            p2 /= p2[3]

            p0[0] = int((p0[0] + 1) * 0.5 * self.w_width)
            p0[1] = int((p0[1] + 1) * 0.5 * self.w_height)
            p1[0] = int((p1[0] + 1) * 0.5 * self.w_width)
            p1[1] = int((p1[1] + 1) * 0.5 * self.w_height)
            p2[0] = int((p2[0] + 1) * 0.5 * self.w_width)
            p2[1] = int((p2[1] + 1) * 0.5 * self.w_height)

            uv0 = [uvs[idx0 * 2], uvs[idx0 * 2 + 1]]
            uv1 = [uvs[idx1 * 2], uvs[idx1 * 2 + 1]]
            uv2 = [uvs[idx2 * 2], uvs[idx2 * 2 + 1]]

            self.rasterizeTriangleCheckerboard(p0, p1, p2, uv0, uv1, uv2, color1, color2, checksize)

    def rasterizeTriangleCheckerboard(self, p0, p1, p2, uv0, uv1, uv2, color1, color2, checksize):
        min_x = max(0, int(min(p0[0], p1[0], p2[0])))
        max_x = min(self.w_width - 1, int(max(p0[0], p1[0], p2[0])))
        min_y = max(0, int(min(p0[1], p1[1], p2[1])))
        max_y = min(self.w_height - 1, int(max(p0[1], p1[1], p2[1])))

        def edgeFunction(v0, v1, p):
            return (p[0] - v0[0]) * (v1[1] - v0[1]) - (p[1] - v0[1]) * (v1[0] - v0[0])

        area = edgeFunction(p0, p1, p2)

        if abs(area) < 1e-7:
            return

        for x in range(min_x, max_x + 1):
            for y in range(min_y, max_y + 1):
                p = [x, y]
                w0 = edgeFunction(p1, p2, p)
                w1 = edgeFunction(p2, p0, p)
                w2 = edgeFunction(p0, p1, p)

                if w0 >= 0 and w1 >= 0 and w2 >= 0:

                    w0 /= area
                    w1 /= area
                    w2 /= area

                    u = w0 * uv0[0] + w1 * uv1[0] + w2 * uv2[0]
                    v = w0 * uv0[1] + w1 * uv1[1] + w2 * uv2[1]

                    if checksize > 0:
                        urow = int(u / checksize) % 2
                        vrow = int(v / checksize) % 2

                        color = color1 if urow == vrow else color2

                        self.win.set_pixel(x, y, color[0], color[1], color[2])

    def keyboard(self, key):
        if key == '1':
            self.keypressed = 1
            self.go()
        if key == '2':
            self.keypressed = 2
            self.go()
