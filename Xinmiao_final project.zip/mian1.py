from rit_window import *
from cgI_engine import *
from shapes import *
import numpy as np
from PIL import Image


def create_scene(myEngine, position, viewT, projectionT):
    base_transform = myEngine.translate3D(position[0], position[1], position[2])
    im1 = Image.open("floor.jpg")  # Floor texture
    im2 = Image.open("wall.jpg")   # Wall texture
    im3 = Image.open("wall2.jpg")

    # Floor (textured)
    myEngine.pushMatrix(base_transform @
                        myEngine.translate3D(0, -2, -2) @
                        myEngine.scale3D(6, 0.1, 2.8))
    modelT = myEngine.getCurrentMatrix()
    myEngine.drawTrianglesTextures(cube, cube_idx, cube_uv, im1, modelT, viewT, projectionT)
    myEngine.popMatrix()

    # Lower walls (textured)
    for x in [-3.1, 3.1]:  # Left and right walls
        myEngine.pushMatrix(base_transform @
                            myEngine.translate3D(x, -1.5, -2) @
                            myEngine.scale3D(0.2, 1.2, 2.5))
        modelT = myEngine.getCurrentMatrix()
        myEngine.drawTrianglesTextures(cube, cube_idx, cube_uv, im2, modelT, viewT, projectionT)
        myEngine.popMatrix()

    # Back wall 1 (textured)
    myEngine.pushMatrix(base_transform @
                        myEngine.translate3D(0, -1.5, -3.5) @
                        myEngine.scale3D(6.2, 1.2, 0.1))
    modelT = myEngine.getCurrentMatrix()
    myEngine.drawTrianglesTextures(cube, cube_idx, cube_uv, im2, modelT, viewT, projectionT)
    myEngine.popMatrix()

    # Upper walls (white texture)
    for x in [-3.1, 3.1]:  # Left and right walls
        myEngine.pushMatrix(base_transform @
                            myEngine.translate3D(x, 0.1, -2) @
                            myEngine.scale3D(0.2, 2, 2.5))
        modelT = myEngine.getCurrentMatrix()
        myEngine.drawTrianglesTextures(cube, cube_idx, cube_uv, im3, modelT, viewT, projectionT)
        myEngine.popMatrix()

    # Back wall 2 with Phong shading to simulate the light
    myEngine.pushMatrix(base_transform @
                        myEngine.translate3D(0, 0.1, -3.5) @
                        myEngine.scale3D(6.2, 2, 0.1))
    modelT = myEngine.getCurrentMatrix()
    myEngine.drawTrianglesPhong(
                                cube, cube_idx, cube_normals, modelT, viewT, projectionT, [1, 1, 1], [1.0, 1.0, 1.0], [0.8, 0.9, 0.2], 50.0,
                                [-2, 6.0, 2.5],  [0.6, 0.8, 1.0], [1, 1, 1], False)
    myEngine.popMatrix()

    # Horizontal Ceiling Beams
    # Left ceiling beam
    myEngine.pushMatrix(base_transform @
                        myEngine.translate3D(-1.8, 1.1, -2) @  # Position to the left of the skylight
                        myEngine.scale3D(2.5, 0.1, 2.5))        # Scale thin beam
    myEngine.drawTriangles3D(cube, cube_idx, myEngine.getCurrentMatrix(), viewT, projectionT, 0.9, 0.9, 0.9)
    myEngine.popMatrix()
    # Right ceiling beam
    myEngine.pushMatrix(base_transform @
                        myEngine.translate3D(1.8, 1.1, -2) @  # Position to the right of the skylight
                        myEngine.scale3D(2.5, 0.1, 2.5))        # Scale thin beam
    myEngine.drawTriangles3D(cube, cube_idx, myEngine.getCurrentMatrix(), viewT, projectionT, 0.9, 0.9, 0.9)
    myEngine.popMatrix()



def create_objects(myEngine, position, viewT, projectionT):
    base_transform = myEngine.translate3D(position[0], position[1], position[2])
    # Draw a cylinder
    myEngine.pushMatrix (base_transform@
            myEngine.translate3D(-1.5, -2.0, -5.0) @
            myEngine.scale3D(0.8, 0.8, 0.8))
    modelT = myEngine.getCurrentMatrix()
    myEngine.drawTrianglesCheckerboard(cylinder, cylinder_idx, cylinder_uv, [1.0, 1.0, 1.0], [0.8, 0.8, 0.8], 0.1, modelT,
                                       viewT, projectionT)
    myEngine.popMatrix()

    # Draw a sphere
    myEngine.pushMatrix (base_transform@
        myEngine.translate3D(1.5, -1.5, -1.0) @
        myEngine.scale3D(0.6, 0.6, 0.6))
    modelT = myEngine.getCurrentMatrix()
    myEngine.drawTrianglesPhong(sphere, sphere_idx, sphere_normals, modelT, viewT, projectionT, [1, 1, 1],
                                [1.0, 1.0, 1.0], [0.8, 0.9, 0.2], 10.0, [-2.0, 3.0, -2.0], [1.0, 1.0, 1.0],
                                [1.0, 1.0, 1.0], True)
    myEngine.popMatrix()




def default_action():
    # clear the FB
    myEngine.clearFB(0.305, 0.475, 0.741)

    myEngine.defineViewWindow(800, 0, 800, 0)

    eye = [0.0, 0, 5.0]
    lookat = [0.0, 0.0, 0.0]
    up = [0.0, 1.0, 0.0]
    viewT = myEngine.lookAt(eye, lookat, up)
    projectionT = myEngine.frustum3D(-6, 6, -6, 6, 8.0, 15.0)

    create_scene(myEngine, [0, 0.0, 0], viewT, projectionT)
    # add a sphere and a cylinder to the scene
    create_objects(myEngine, [0, 0.0, 0.0], viewT, projectionT)



window = RitWindow(800, 800)
myEngine = CGIengine(window, default_action)


def main():
    window.run(myEngine)


if __name__ == "__main__":
    main()
